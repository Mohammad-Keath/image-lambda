# image-lambda
  - ## a description of how to use your lambda.
    1. we will search of lamda on aws
    2. press create function
    3. choose author from scratch and write the func name then as a normal user press on create new role
    4. search of S3 
    5. click create create bucket
    6. then write name of the bucket and choose ACLs enabled
    7. uncheck block all public access
    8. then press create bucket
    9. then go inside it and upload any file or folder you want to add
    10. then go back to the lamda and press add triger and add the s3 to it
    11. then change the permission to read for all 
  - ## a description of any issues you encountered during deployment of this lambda.
  - ## a link to your images.json file.