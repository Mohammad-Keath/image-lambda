const AWS = require('aws-sdk')
const s3 = new AWS.S3()

export const handler = async (event)=>{
    if(!arr){
        let arr = [{}]
    }
    let length = arr.length
    arr[length-1].Name = s3.getBucketAcl
    return arr
}